function navigateTo(filename) {
  window.location = filename;
  console.log("Redirecting to " + filename);
}